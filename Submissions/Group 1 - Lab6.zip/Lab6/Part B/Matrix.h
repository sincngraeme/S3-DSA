// implementation of multiplication functions

#ifndef MATRIX_H
#define MATRIX_H

void MultiplyAx(float* A, int n , int m, float* x1, float* y1 );
void MultiplyHx(int* A, int n , int m, int* x1, int* y1 );

#endif