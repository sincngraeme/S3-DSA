/* Matrix.h - Interface for matrix multiplication
 * Author: MG
 *
 */

#ifndef MATRIX_H
#define MATRIX_H

void MultiplyHx_bitwise(unsigned int H, int nRows, int mCols, unsigned char x, unsigned char* y);

#endif
