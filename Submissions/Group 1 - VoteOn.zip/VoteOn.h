#include <malloc.h>

int VoteOn( void *Instances[], int nInstances, int nSize);